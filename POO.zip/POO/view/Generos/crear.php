<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles/Genros/estilo.css">
    <title>Registrate |</title>
</head>
<body>
    <div id="titulo">
        <h1 id="tit1">E-BOOK</h1>
    </div>
    <div id="config-form">
        <form  method="POST" action="../../scripts/Generos/crear.php" >
            <div class="input-group">
                <h2 id="pti">REGISTRO DE GENEROS</h2>      
                <label for="Nombre">    Genero:  </label> <input type="text" name="nombre"  placeholder="Genero"> 
                <input class="btn" type="submit" value="Crear">
            </div>
        </form>
    </div>
</body>
</html>