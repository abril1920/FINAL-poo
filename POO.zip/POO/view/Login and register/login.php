<?php   
    if(isset($_POST['submit'])){

        $usu_name       = $_POST['usu_name'];
        $usu_edad       = $_POST['usu_edad'];
        $usu_email      = $_POST['usu_email'];
        $usu_nickname   = $_POST['usu_nickname'];
        $usu_password   = $_POST['usu_password'];
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles/Login and register/login.css">
    <title>Inicio de sesión</title>
</head>
<body>


<div id="config-form">
<form   method="POST" action="../../../POO/index.php">
    <?php
    if(isset($errorLogin)){
        echo $errorLogin;
    }
    ?>
    <div class="input-group">
        <h2 id="pti">Iniciar sesion</h2> 
        <label for="apodo">     apodo   </label>   <input type="text"     name="usu_nickname"    placeholder="apodo">
        <label for="Clave" >Contraseña:</label>     <input type="password"   name="usu_password" placeholder="Contraseña">
        <input class="btn" type="submit" value="Enviar" name="btnIngresar"  >
    </div>
    <h3>No tienes cuenta? registrate desde aqui</h3>
    <a  class="btn" href="./register.php">Registrarse</a>
</form> 
</div>
</body>
</html>


