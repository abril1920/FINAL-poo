<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <div id="a">
    <h2>Ahora inicia sesión</h2>
    <a href="./login.php">
    <button id="btn">Iniciar sesión</button>
    </a> 
    </div>
</body>
</html>


<style>
    *{
    background-color: floralwhite;
    font-family: monospace;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    }


    h2{
        font-size: 30px;
        text-align:center;
        margin-top:100px;
    }

    #btn{
        margin-left:550px;
        font-size: 30px;
        text-align:center;
        margin-top:100px;
        cursor: pointer;
    }
    
</style>
 