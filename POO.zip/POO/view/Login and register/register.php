<?php   
    if(isset($_POST['submit'])){

        $usu_name       = $_POST['usu_name'];
        $usu_edad       = $_POST['usu_edad'];
        $usu_email      = $_POST['usu_email'];
        $usu_nickname   = $_POST['usu_nickname'];
        $usu_password   = $_POST['usu_password'];
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles/Login and register/register.css">
    <title>Registrate</title>
</head>
<body>
    <div id="titulo">
        <h1 id="tit1">E-BOOK</h1>
    </div>

    <div id="container">
    <p id="texto">
        Bienvenido a la pagina online de  <b> E-BOOK.</b>
        <br>
        <br>
        Podras encontrar y adquirir una variedad de libros de acuerdo a tu gusto.
        <br>
        registrate y podras entrar a este mundo 
    </p>
    <div id="config-form">
        <form  method="post" >
            <div class="input-group">
                <h2 id="pti">REGISTRO DE DATOS</h2>    
            <label for="Nombre">Nombre:     </label>   <input type="text"      name="usu_name"    placeholder="Nombre">     
            <label for="Edad">  Edad:       </label>   <input type="text"      name="usu_edad"    placeholder="edad">       
            <label for="Email"> Email:      </label>   <input type="email"     name="usu_email"   placeholder="Email">      
            <label for="Apodo"> Apodo:      </label>   <input type="text"      name="usu_nickname"placeholder="Apodo">     
            <label for="Clave" >Contraseña: </label>   <input type="password"  name="usu_password"placeholder="Contraseña"> <br>
            <input class="btn" type="submit" value="Enviar" name="submit"  >
        </div>
        <?php include('../../scripts/Login and register/create.php')?>
    <div id="config-change">
        <h3>Ya tienes cuenta? Inicia desde aqui</h3>
        <a id="a1" href="./login.php">Iniciar Sesión </a>
    </div>
    <div class="form-txt">
                    <a href="#">Politicas y privacidad</a>
                    <a href="#">Terminos y condiciones</a>
                </div>
            </div>
        </form>
    </div>
</div>  
</body>
</html>
