<?php
                        //ARCHIVO PARA VALIDAR LA INFORMACIÓON DEL REGISTRO E INICIO DE SESIÓN Y REDIRECCIONAR A LA PANTALLA PRINCIPAL
include_once './scripts/Login and register/Validate data.php';
include_once './scripts/Login and register/Usser_session.php';
$userSession    = new UserSession();
$user           = new StarSesion();

if(isset($_SESSION['user'])){

    //echo "hay sesion";
    $user->setUser($userSession->getCurrentUser());
    include_once './view/Home/Home.php';


}else if(isset($_POST['usu_nickname']) && isset($_POST['usu_password'])){
    //echo "validacion  de login";
    // echo ":v";
     //echo var_dump ($_POST);
    $userForm =$_POST['usu_nickname'];
    $passForm =$_POST['usu_password'];
    echo var_dump($user->userExists($userForm, $passForm));
    if($user->userExists($userForm, $passForm)){
       // echo "usuario validado";
       
       $userSession->setCurrentUser($userForm);
       $user -> setUser($userForm);
    }else{
        //echo "nombre de usuario y/o contraseña invalido";
        $errorLogin = "Nombre de usuario y/o contraseña invalido";
        include_once "./view/Login and register/login.php";
    }
}else{
    //echo "login";
    echo "ERROR";
    include_once "./view/Home/Home.php";
}
?>
