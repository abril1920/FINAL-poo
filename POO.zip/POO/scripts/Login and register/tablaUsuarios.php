<?php
 // Conexión con el archivo PHP que conecta la base de datos
 require_once 'conexion.php';
 
 class Usuario {
   private $usu_id;
   private $usu_name;
   private $usu_edad;
   private $usu_email;
   private $usu_nickname;
   private $usu_password;
   private $rols_id;
   const TABLA = 'users';
 


 public function getId() 
    {return $this->usu_id;}

 public function getName() 
    { return $this->usu_name;}

 public function getEdad() 
   { return $this->usu_edad;}

 public function getEmail() 
    {return $this->usu_email;}

 public function getNickname() 
    { return $this->usu_nickname;}
 
 public function getPassword() 
    {return $this->usu_password;}

 public function getRols_id() 
    {return $this->rols_id;}


 public function setName($usu_name) {
    $this->usu_name = $usu_name;
 }
 
 public function setEdad($usu_edad) {
      $this->usu_edad = $usu_edad;    
 }
 public function setEmail($usu_email) {
    $this->usu_email = $usu_email;
 }
 public function setNickname($usu_nickname) {
   $this->usu_nickname = $usu_nickname;
}
 public function setPassword($usu_password) {
    $this->usu_password =$usu_password;
 }
 public function setRols_id($rols_id) {
    $this->rols_id = $rols_id;
 }

 public function __construct($usu_name,$usu_edad, $usu_email,$usu_nickname, $usu_password,$rols_id, $usu_id=null) {
    $this->usu_name     = $usu_name;
    $this->usu_edad     = $usu_edad;
    $this->usu_email    = $usu_email;
    $this->usu_nickname = $usu_nickname;
    $this->usu_password = $usu_password;
    $this->rols_id      = $rols_id;
    $this->usu_id       = $usu_id;
 }






 public function guardar(){
    $conexion = new Conexion();
{
       $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (usu_name, usu_edad, usu_email, usu_nickname, usu_password, rols_id) VALUES(:usu_name, :usu_edad, :usu_email, :usu_nickname, :usu_password, :rols_id)');
       $consulta->bindParam(':usu_name',    $this->usu_name);
       $consulta->bindParam(':usu_edad',    $this->usu_edad);
       $consulta->bindParam(':usu_email',   $this->usu_email);
       $consulta->bindParam(':usu_nickname',$this->usu_nickname);
       $consulta->bindParam(':usu_password',$this->usu_password);
       $consulta->bindParam(':rols_id'    , $this->rols_id);
       $consulta->execute();
       $this->usu_id = $conexion->lastInsertId();
    }
    $conexion = null;
 }

 public static function recuperarTodos(){
    $conexion =new Conexion();
    $consulta = $conexion->prepare('SELECT usu_id,usu_name FROM'.self::TABLA.' ORDER BY nombre ASC');
    $consulta->execute();
    $registro = $consulta ->fetchAll();
    return $registro;
}
}





?>