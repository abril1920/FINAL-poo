<?php
                                        //Este archivo fue creado para validar los datos guardados en la base de datos para un incio de seion
    require_once 'conexion.php';
    class StarSesion{

        private $usu_name;
        private $usu_nickname;

        public function userExists($user, $pass){  // para validar en la BD que existe en la base de datos
            $md5pass = md5($pass);         
            
            $conexion = new Conexion();
            $query = $conexion->prepare("SELECT * FROM users WHERE usu_nickname = $user AND usu_password = $pass");
            $query->execute();
            if($query->rowCount()){   // valida si rowcount es una funcion y permite ver el num de filas para validar si el login fue incorrecto
                return true;
            }else{
                return false;
            }
        }


        public function setUser($user){

            $conexion = new Conexion();
            $query = $conexion-> prepare('SELECT * FROM users WHERE usu_nickname = :user');
            $query->execute(['user'=> $user]);
            foreach($query as $CurrentUser){
                return $query->fetchAll();
                $this->usu_name = $CurrentUser['usu_name'];
                $this->usu_nickname = $CurrentUser['usu_nickname'];
            }
        }


        public function getName(){
            return $this->usu_nickname;
        }
    }










 /*   include 'tablaUsuarios.php';
    session_start();

    if(!empty($_POST["btnIngresar"])){

        if (!empty($_POST['usu_email']) and !empty($_POST['usu_password'])){

            $usu_email      =$_POST['usu_email'];
            $usu_password   =$_POST['usu_password'];
            $sql= query(" SELECT * FROM users WHERE usu_email='$usu_email' AND usu_password='$usu_password'");

            if($datos=$sql->fetch_object()){

                $_SESSION["usu_id"]         =$datos->usu_id;
                $_SESSION["usu_name"]       =$datos->usu_name;
                $_SESSION["usu_edad"]       =$datos->usu_edad;
                $_SESSION["usu_nickname"]  =$datos->usu_nickname;
                header('location: ../pantalla_prinicipal/principal.php');
            }else{
                echo "<p id='error'> Acceso denegado </p>";
            }
        }else{
            echo "<p id='error'> Campos vacios </p>";;
        }
    }*/
?>