<?php
                                        // archivo solo para cerrar sesión
    include_once './Usser_session.php';

    $userSession = new UserSession();
    $userSession ->closeSession();

    header("location: ../../view/Login and register/login.php");

?>