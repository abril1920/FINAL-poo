<?php                   // ESTE ARCHIVO ES PARA MODIFICAR Y USAR LA SESIONES PASADAS
class UserSession{

    public function __construct(){          //contructor
        session_start();                    //se modifica las sesiones que estamos creando
    }

    public function setCurrentUser($user){       //ayuda a poner valor a una sesion actual
        $_SESSION['user'] = $user;              //guarda un nombre en la variable
    }

    public function getCurrentUser(){       //para devolver la session pasada
        return $_SESSION['user'];
    }

    public function closeSession(){         //para cerrar sesion
        session_unset();                    //borra valores de las sesiones
        session_destroy();                  //borra la sesion como tal
    }
}
?>