<?php
  include 'tablaUsuarios.php';
    if(empty($usu_name) or ($usu_name) == " "){
  echo ':v';
       // echo "<p id='error'> Agrega tu nombre </p>";
    }else{
        if(strlen($usu_name) > 18){
            //echo "<p id='error'> El nombre ingresado es demasiado largo</p>";
        }else{
            if(is_numeric($usu_name)){
                //echo "<p id='error'> No puedes agregar numeros</p>";
            }else{
                if (!empty($usu_name) and !empty($usu_edad) and !empty($usu_email) and !empty($usu_nickname) and !empty($usu_password)){
                    $registro = new Usuario($_POST['usu_name'],$_POST['usu_edad'],$_POST['usu_email'],$_POST['usu_nickname'],$_POST['usu_password'],1);
                    $registro->guardar();
                    echo $registro->getName() . ' se ha guardado correctamente con el id: ' . $registro->getId();
                    header('location: ../../view/Login and register/redireccionar.php');
                }
            }
        }
    }

    if(empty($usu_edad) or ($usu_edad) == " "){
        //echo "<p id='error'> Agrega tu edad </p>";
    }else{
        if(!is_numeric($usu_edad)){
            echo "<p id='error'> agrega dato númerico </p>";
        }else{
            
        }
    }

    if(empty($usu_email) or ($usu_email) == " "){
        //echo "<p id='error'> Agrega tu email </p>";
    }else{
        if(!filter_var($usu_email, FILTER_VALIDATE_EMAIL)){
           // echo "<p id='error'> El correo es incorrecto  </p>";
        }else{
            
        }
    }

    if(empty($usu_nickname) or ($usu_nickname) == " "){
        //echo "<p id='error'> Agrega tu apodo </p>";
    }else{
        if(strlen($usu_nickname) > 18 ){
            echo "<p id='error'> Ingresa un apodo </p>";
        }else{
            if(is_numeric($usu_nickname)){
                echo "<p id='error'> No puedes agregar numeros</p>";
            }else{
                
            }
        }
    }

    if(empty($usu_password) or ($usu_password) == " "){
        //echo "<p id='error'> Agrega tu contraseña </p>";
    }else{
        if ( strlen($usu_password) > 30 ){
            //echo "<p id='error'> la contraseña es muy larga </p>";
        }else{
            
        }
    }

 
?>

